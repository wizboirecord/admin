import {run} from './main';

run();
